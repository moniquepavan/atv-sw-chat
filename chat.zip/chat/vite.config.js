// vite.config.js
export default {
    server: {
      // Desativa a solicitação de favicon
      watch: {
        disableGlobbing: true,
      },
    },
  };
  