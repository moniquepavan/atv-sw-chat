
import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Home from './pages/Home';
import ChatComponent from './components/Chat';
import SecondScreen from './components/SecondScreen'; 

const App = () => {
  const [username, setUsername] = useState('');

  return (
    <Router>
      <Switch>
         <Route path="/" exact render={() => <Home setUsername={setUsername} />} />
         <Route path="/chat" render={() => <ChatComponent username={username} />} />
         <Route path="/second-screen" component={SecondScreen} />
      </Switch>
    </Router>
  );
};

export default App;
