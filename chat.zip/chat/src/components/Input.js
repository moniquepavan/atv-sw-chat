import React, { useState } from 'react';

const Input = ({ onSubmit }) => {
  const [name, setName] = useState('');

  const handleClick = () => {
    onSubmit(name);
  };

  return (
    <div>
      <input
        type="text"
        placeholder="Digite seu nome..."
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <button onClick={handleClick}>Entrar</button>
    </div>
  );
};

export default Input;
