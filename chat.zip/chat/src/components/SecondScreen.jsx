
import React from 'react';

const SecondScreen = () => {
  return (
    <div>
      <h1>Segunda Tela</h1>
      <p>Conteúdo da segunda tela.</p>
    </div>
  );
};

export default SecondScreen;
