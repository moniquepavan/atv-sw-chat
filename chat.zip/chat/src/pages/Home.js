import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';

const Home = ({ setUsername }) => {
  const [name, setName] = useState('');
  const history = useHistory();

  const handleStartChat = () => {
    if (name.trim() !== '') {
      setUsername(name);
      history.push('/chat');
    }
  };

  const handleGoToSecondScreen = () => {
    console.log("Clicou em Ir para Segunda Tela");
    history.push('/second-screen');
  };

  return (
    <div>
      <h1>Bem-vindo ao Chat</h1>
      <label htmlFor="name">Digite seu nome: </label>
      <input
        type="text"
        id="name"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <button onClick={handleStartChat}>Iniciar Chat</button>
      <button onClick={handleGoToSecondScreen}>Ir para Segunda Tela</button>
    </div>
  );
};

export default Home;
