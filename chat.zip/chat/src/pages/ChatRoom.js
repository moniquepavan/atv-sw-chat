import React from 'react';
import Chat from '../components/Chat';

const ChatRoom = ({ username }) => {
  return (
    <div>
      <h1>Sala de Chat</h1>
      <p>Bem-vindo, {username}!</p>
      <Chat username={username} />
    </div>
  );
};

export default ChatRoom;
